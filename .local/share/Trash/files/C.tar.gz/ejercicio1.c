#include <stdio.h>
#include <sys/types.h> 

main()
{
	int i, j=1;

	for(i=1; i<3; ++i)
	{	
		fork();
		printf("%d,%d\n",i,j);
		j++;
	}
}