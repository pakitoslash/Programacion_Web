#include <stdio.h>
#include <string.h>
#include <sys/types.h>


int main(int argc, char const *argv[])
{
	int e, i,j, padre;

	//padre = fork();

	for (i=1; i<4; ++i)
	{
		if (fork()>0)
		{
			
			wait();

		}
		else
		{
			printf("%d\n",i);
		}
	}
	return 0;
}