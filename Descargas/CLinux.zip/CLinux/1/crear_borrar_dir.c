#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>

int main(int argc, char const *argv[])
{
	int borra;
	char buffer[512];

	printf("El directorio actual es: %s\n", getcwd(buffer, -1));
	mkdir("/home/proteco/Escritorio/Prueba",0755);
	chdir("/home/proteco/Escritorio/Prueba");
    mkdir("./Directorio1",755);
    mkdir("./Directorio2",755);
    printf("\nSe crearon los directorios Directorio1 y Directorio1");

    printf("quiere borrar Directorio1?(si-1 no-2)");
    scanf("%d",&borra);
    if(borra==1)
    	rmdir("./Directorio1");

	return 0;
}