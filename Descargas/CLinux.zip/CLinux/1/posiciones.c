#include <sys/type.h>
#include <unistd.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>

int main(int argc, char const *argv[])
{
	char archivo_temp[]="nuevo.txt";
	char buf[10];
	struct stat statbuf;
	int i,descriptor_archivo,descriptor_salida;

	if((descriptor_archivo=open("ejemplo.txt",O_RDONLY))<0){
		perror("open nuevo");
		exit(EXIT_FAILURE);	
	}

	if ((descriptor_salida=open(archivo_temp, O_CREAT | O_WRONLY,0644))<0)
	{
		perror("open nuevo");
		exit(EXIT_FAILURE);	
	}
	printf("El archivo de salida es %s\n",archivo_temp );

	for ( i = 0; i < 10; ++i)
	{
		read(descriptor_archivo,buf,10);
		write(descriptor_salida,buf,10);
		lseek(descriptor_archivo,100,SEEK_SET);
	}
	
	close(descriptor_archivo);
	close(descriptor_salida);

	return 0;
}
