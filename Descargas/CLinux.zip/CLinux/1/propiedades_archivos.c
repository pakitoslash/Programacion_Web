#include <unistd.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <time.h>
int main(){
	struct stat buf;
	mode_t modo;
	char tipo_de_archivo[80],*archivo="src.txt";
	int descriptor_archivo;

	if ((descriptor_archivo=open(archivo,O_RDONLY))<0)
		{
			perror("en la apertura");
			exit(EXIT_FAILURE);
		}	
		if ((fstat(descriptor_archivo,&buf))<0)
		{
			perror("stat");
			close(descriptor_archivo);
			exit(EXIT_FAILURE);
		}
		modo = buf.st_mode;
		printf("Archivo: %s\n",archivo);
		printf("INODE: %ld\n",(long)buf.st_ino);
		printf("Dispositivo: %ld, %ld\n",(long)major(buf.st_dev),(long)minor(buf.st_dev) );
		printf("Modo: %#o\n",buf.st_mode & -(S_IFMT) );

		printf("Tamaño: %ld\n",buf.st_size);

		if ((close(descriptor_archivo))<0)
		{
			perror("close");
			exit(EXIT_FAILURE);
		}
		exit(EXIT_SUCCESS) ;

	}