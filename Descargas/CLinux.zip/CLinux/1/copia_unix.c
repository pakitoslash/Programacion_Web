#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
int main(){
	int src,des,bytes;
	char buf[10];
	src = open("src.txt",O_RDONLY);
	des = open("destino.txt",O_RDWR|O_CREAT);
	if(src<0 || des<0){
		perror("open src o des");
		exit(EXIT_FAILURE);
	}
   while((bytes = read(src,buf,bytes))!=0){
   		if((write(des,buf,bytes))<0){
   			perror("eror de escritura");
   		}
   }

   close(src);
   close(des);

	return 0;
	}
