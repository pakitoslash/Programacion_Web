#include <stdio.h>
#include <sys/dir.h>

int main(int argc, char const *argv[])
{
	DIR *dir;
	struct dirent *p;

	if((dir = opendir("/home/proteco")) != NULL){
		while((p= readdir(dir))!=NULL)
			printf("\n[%s]\n",(p->d_name));

		closedir(dir);
	}


     printf("\n");
	return 0;
}