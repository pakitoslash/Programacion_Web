#include <stdio.h>
#include <stdlib.h>

int main()
{
	int x;
 	FILE *src = fopen("src.txt","r");
	FILE *des = fopen("destino.txt","w");

	if (src==NULL || des==NULL)
		exit(1);

	while(!feof(src)){
		x= fgetc(src);
		fputc(x,des);
	}

	fclose(src);
	fclose(des);


	return 0;
}